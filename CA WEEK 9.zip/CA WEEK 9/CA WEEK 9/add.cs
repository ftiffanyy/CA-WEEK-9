﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_9
{
    public partial class add : Form
    {
        Form1 form = Application.OpenForms["Form1"] as Form1;
        public add()
        {
            InitializeComponent();
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            bool yn = false;
            foreach(string x in form.nama)
            {
                if(x == tb_username.Text)
                {
                    yn = true;
                    MessageBox.Show("USERNAME SAMA");
                    break;
                }
            }
            if (tb_passw.Text == tb_confirm.Text)
            {
                form.nama.Add(tb_username.Text);
                form.pass.Add(tb_passw.Text);
                tb_username.Text = "";
                tb_passw.Text = "";
                tb_confirm.Text = "";
            }
            else
            {
                MessageBox.Show("PASSWORD TIDAK SAMA");
            }
        }

        private void add_Load(object sender, EventArgs e)
        {
        }
    }
}
