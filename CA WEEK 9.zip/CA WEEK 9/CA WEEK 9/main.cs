﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_9
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void main_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            add formadd = new add();
            formadd.MdiParent = this;
            formadd.Show();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Nama(string x)
        {
            tss_nama.Text = x;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            tss_waktu.Text = DateTime.Now.ToString("ddd, dd - MM - yyyy HH:mm:ss");
            waktu.Text = DateTime.Now.ToString("ddd, dd - MM - yyyy HH:mm:ss");
        }
    }
}
