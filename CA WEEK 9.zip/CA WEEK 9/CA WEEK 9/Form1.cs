﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_WEEK_9
{
    public partial class Form1 : Form
    {
        public List<string> nama = new List<string>();
        public List<string> pass = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            bool yn = false;
            int index = 0;
            for(int i = 0; i < nama.Count; i++)
            {
                if (nama[i] == tb_user.Text)
                {
                    index = i;
                    yn = true; break;
                }
            }
            if (pass[index] == tb_pass.Text && yn == true)
            {
                main main = new main();
                main.Nama(nama[index]);
                main.Show();
                tb_user.Text = "";
                tb_pass.Text = "";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            nama.Add("admin");
            pass.Add("admin");
        }
    }
}
